package com.gradiuss.game.models;

import android.graphics.Bitmap;

public class ScoreLabel extends GameObject {
	
	public ScoreLabel(Bitmap bitmap, float x, float y) {
		super(bitmap, x, y);
		
	}

	@Override
	public void initialize() {
		
	}


}
